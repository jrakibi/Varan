<!--
GitHub is reserved for bug reports and feature requests. 
Please include one and only one of the below blocks
in your new issue.
-->

<!--
If you are filing a bug report, please remove the below feature
request block and provide responses for all of the below items.
-->

**Symfony FOSUserBundle versions**:

<!--
You can run `composer info` in your project to get those informations
-->

**Description of the problem including expected versus actual behavior**:

**Steps to reproduce**:
 1.
 2.
 3.

**Provide logs (if relevant)**:

<!--
If you are filing a feature request, please remove the above bug
report block and provide responses for all of the below items.
-->

**Describe the feature**:
